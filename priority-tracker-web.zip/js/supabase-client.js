// ============================================================================
// Supabase client setup
// ============================================================================
// Fill these in once the Supabase project exists (Project Settings → API).
// The anon key is meant to be public — it's safe to ship in client-side code
// because Row Level Security (see supabase_schema.sql) is what actually
// controls who can read/write what, not this key.
const SUPABASE_URL = 'YOUR_SUPABASE_PROJECT_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';

const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
