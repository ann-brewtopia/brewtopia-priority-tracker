// ============================================================================
// Auth — replaces the old "claim your ticket" soft identity picker with a
// real signed-in user. There's no more per-browser guessing: whoever is
// signed in IS the identity, enforced server-side by Row Level Security,
// not just hidden by the UI.
// ============================================================================

let currentUser = null;     // the Supabase auth user object, or null if signed out
let currentProfile = null;  // { id, full_name, role } from public.profiles

async function initAuth(){
  const { data: { session } } = await supabase.auth.getSession();
  if(session){
    await loadCurrentProfile(session.user);
  }
  showAuthUI();

  // Fires on sign-in, sign-out, and token refresh — keeps currentUser/
  // currentProfile correct without the page needing a manual reload.
  supabase.auth.onAuthStateChange(async (event, session) => {
    if(session){
      await loadCurrentProfile(session.user);
    }else{
      currentUser = null;
      currentProfile = null;
    }
    showAuthUI();
    if(session) await loadAllData();
  });
}

async function loadCurrentProfile(user){
  currentUser = user;
  const { data, error } = await supabase
    .from('profiles')
    .select('id, full_name, role')
    .eq('id', user.id)
    .single();
  if(error){
    console.error('Could not load profile', error);
    currentProfile = { id: user.id, full_name: user.email, role: 'member' };
  }else{
    currentProfile = data;
  }
}

function isAdmin(){
  return !!currentProfile && currentProfile.role === 'admin';
}

// Sends a magic link — no password to manage or forget. The link takes them
// straight back into the app, already signed in.
async function sendMagicLink(email){
  const { error } = await supabase.auth.signInWithOtp({
    email,
    options: { emailRedirectTo: window.location.origin }
  });
  return error;
}

async function signOut(){
  await supabase.auth.signOut();
}

function showAuthUI(){
  const loginScreen = document.getElementById('loginScreen');
  const appRoot = document.getElementById('appRoot');
  if(currentUser){
    loginScreen.style.display = 'none';
    appRoot.style.display = '';
    const label = document.getElementById('currentUserLabel');
    if(label){
      label.innerHTML = `Signed in as <strong>${escapeHtml(currentProfile.full_name || currentUser.email)}</strong>` +
        (isAdmin() ? ' — Admin' : '');
    }
  }else{
    loginScreen.style.display = '';
    appRoot.style.display = 'none';
  }
}

document.getElementById('magicLinkForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const emailInput = document.getElementById('magicLinkEmail');
  const note = document.getElementById('magicLinkNote');
  const email = emailInput.value.trim();
  if(!email) return;
  note.innerText = 'Sending…';
  const error = await sendMagicLink(email);
  note.innerText = error
    ? `Couldn't send that: ${error.message}`
    : `Check ${email} for a sign-in link.`;
});

document.getElementById('signOutBtn').addEventListener('click', signOut);
